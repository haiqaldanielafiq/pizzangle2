PIZZANGLE - Boy Pizzangle character assets

These PNGs have transparent backgrounds.

Main animation states:
boy-idle.png - idle / waving
boy-happy.png - correct answer / celebration
boy-thinking.png - wrong answer / thinking
boy-sad.png - game over
boy-scooter.png - mission complete / delivery

Additional poses:
boy-pizza.png - holding pizza
boy-teacher.png - explains answers
boy-trophy.png - achievement

Upload this assets folder into the same project as index.html.
Reference the images with assets/boy-idle.png, etc.
To keep a genuinely single-file HTML release, the PNGs can be embedded as Base64 data URLs during the final build.

Independent educational game visual; brand logo permissions should be checked before public distribution.
